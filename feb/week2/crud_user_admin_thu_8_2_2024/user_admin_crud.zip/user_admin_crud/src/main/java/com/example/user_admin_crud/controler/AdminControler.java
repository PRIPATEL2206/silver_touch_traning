package com.example.user_admin_crud.controler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.user_admin_crud.models.AdminModel;
import com.example.user_admin_crud.repos.AdminRepo;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.bind.annotation.RequestBody;

@Controller
public class AdminControler {

    @Autowired
    private AdminRepo adminRepo;

    // @Autowired
    // private JdbcUserDetailsManager userDetailsManager;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // @Autowired
    // private AuthenticationManager authenticationManager;

    @GetMapping("/adminRegister")
    public String adminRegister() {
        return "registerAdmin";
    }

    @PostMapping("/adminRegister")
    public String registerAdmin(@ModelAttribute AdminModel admin, RedirectAttributes redirectives) {

        try {
            // String s = principal.getName();

            // add athority
            // List<String> authorities = new ArrayList<String>();
            // authorities.add("ADMIN");
            // List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
            // authorities.add(new SimpleGrantedAuthority("ADMIN"));

            // create user
            // UserDetails user = new User(admin.getUsername(),
            // passwordEncoder.encode(admin.getPassword()), authorities);
            // userDetailsManager.createUser(user);

            // authenticate user
            // Authentication a = authenticationManager
            // .authenticate(new UsernamePasswordAuthenticationToken(admin.getUsername(),
            // admin.getPassword()));
            // System.out.println(a);

            // Authentication authentication = new UsernamePasswordAuthenticationToken(user,
            // null, authorities);
            // SecurityContextHolder.getContext().setAuthentication(authentication);

            System.out.println("ok");
            // save admin
            admin.setPassword(passwordEncoder.encode(admin.getPassword()));
            admin.setRole("ADMIN");
            System.out.println("ok");
            // User user = new User();
            // user.setName(admin.getUsername());
            // user.setPassword(admin.getPassword());
            // user.setRoles(authorities);
            // userRepo.save(user);
            adminRepo.save(admin);

        } catch (Exception e) {
            System.out.println(e);
        }
        return "redirect:/adminDashbord";
    }

    @GetMapping("/adminDashbord")
    public String adminDashbord() {
        return "adminDashbord";
    }

    @GetMapping("/login")
    public String loginPage() {
        return "login";
    }

    @PostMapping("/login")
    public String login(@RequestBody String entity) {
        if (true) {
            // if user in employee
            int id = 1;
            return "redirect:/user" + id;
        }
        // else send to admin dashbord
        return "redirect:/adminDashbord";
    }

}

package com.example.user_admin_crud.controler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.user_admin_crud.models.EmployeeModel;
import com.example.user_admin_crud.repos.EmployeeRepo;

@Controller
public class UserControler {

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    EmployeeRepo employeeRepo;

    @GetMapping("/addEmployee")
    public String addUser() {
        return "addEmployee";
    }

    @PostMapping("/addEmployee")
    public String addEmployee(@ModelAttribute EmployeeModel employee) {
        employee.setRole("EMPLOYEE");

        employee.setPassword(passwordEncoder.encode(employee.getPassword()));
        employeeRepo.save(employee);
        return "redirect:/addEmployee";
    }

    @GetMapping("/allUsers")
    public String getAllUser(Model model) {
        model.addAttribute("employees", employeeRepo.findAll());
        return "allUsers";
    }

    @GetMapping("delete/{id}")
    public String read(@PathVariable("id") int employeeId, Model model) {
        System.err.println(employeeId);
        EmployeeModel emp = employeeRepo.getReferenceById(employeeId);
        employeeRepo.delete(emp);
        return "redirect:/allUsers";
    }

    @GetMapping("updateEmployee/{id}")
    public String getUpdatePage(@PathVariable("id") int employeeId, Model model) {
        EmployeeModel emp = employeeRepo.getReferenceById(employeeId);
        System.out.println(emp.getAddress());
        model.addAttribute("employee", emp);
        return "updateEmployee";
    }

    @PostMapping("updateEmployee/{id}")
    public String updatePage(@PathVariable("id") int employeeId, @ModelAttribute EmployeeModel updateEmp, Model model) {
        updateEmp.setId(employeeId);
        employeeRepo.save(updateEmp);

        return "redirect:/allUsers";
    }

    @GetMapping("/user/{id}")
    public String getMethodName(@PathVariable("id") int employeeId, Model model) {
        EmployeeModel emp = employeeRepo.getReferenceById(employeeId);
        model.addAttribute("employee", emp);
        return "user";
    }

}

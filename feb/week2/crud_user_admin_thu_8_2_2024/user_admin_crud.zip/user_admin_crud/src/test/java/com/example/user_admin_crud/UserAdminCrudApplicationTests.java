package com.example.user_admin_crud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserAdminCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
